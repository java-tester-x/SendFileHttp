//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SMTPAuthenticationfrm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmSMTPAuthentication *frmSMTPAuthentication;
//---------------------------------------------------------------------------
__fastcall TfrmSMTPAuthentication::TfrmSMTPAuthentication(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
