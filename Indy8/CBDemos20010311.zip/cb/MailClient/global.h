#if !defined (GLOBAL_H)
#define GLOBAL_H
extern AnsiString  Pop3ServerName ;
extern int         Pop3ServerPort;
extern AnsiString  Pop3ServerUser;
extern AnsiString  Pop3ServerPassword;
extern AnsiString  SmtpServerName;
extern int         SmtpServerPort;
extern AnsiString  SmtpServerUser;
extern AnsiString  SmtpServerPassword;
extern int         SmtpAuthType;
extern AnsiString  UserEmail;
#endif
