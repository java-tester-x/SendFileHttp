//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MsgEditAdvFrm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmMsgEditAdv *frmMsgEditAdv;
//---------------------------------------------------------------------------
__fastcall TfrmMsgEditAdv::TfrmMsgEditAdv(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

